/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    Siteusercoverphoto
 * @copyright  Copyright 2012-2013 BigStep Technologies Pvt. Ltd.
 * @license    http://www.socialengineaddons.com/license/
 * @version    $Id: my.sql 6590 2013-06-03 00:00:00Z SocialEngineAddOns $
 * @author     SocialEngineAddOns
 */

INSERT IGNORE INTO `engine4_core_modules` (`name`, `title`, `description`, `version`, `enabled`,
`type`) VALUES  ('siteusercoverphoto', 'User Profiles - Cover Photo, Banner & Site Branding', 'User Profiles - Cover Photo, Banner & Site Branding','4.8.9p1', 1, 'extra');
